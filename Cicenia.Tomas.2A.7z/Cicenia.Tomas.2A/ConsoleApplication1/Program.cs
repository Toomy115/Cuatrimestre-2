﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades;
using System.Data;
using System.Data.SqlClient;

namespace ConsoleApplication1
{
    public delegate string ListadoBD(ISerializable obj);

    class Program
    {
        public event ListadoBD Del;

        private static bool Deserealizar(ISerializable obj)
        {
            return obj.DeserealizarXML();
        }

        private static string ObtenerPreciosBD(ISerializable obj)
        {
            SqlConnection _miObjeto = new SqlConnection(Properties.Settings.Default.Setting);
            SqlCommand sc = new SqlCommand();
            sc.Connection = _miObjeto;
            sc.CommandType = CommandType.Text;
            sc.CommandText = ("SELECT id, descripcion, precio FROM PreciosFruta");
            _miObjeto.Open();
            SqlDataReader Dr = sc.ExecuteReader();           
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("\nLECTURA DE LA BASE DE DATOS\n");
            while (Dr.Read())
            {               
                sb.AppendLine("ID: " + Dr[0].ToString() + " Descripcion: " + Dr[1] + " Precio: " + Dr[2]);
            }
            Dr.Close();
            _miObjeto.Close();
            return sb.ToString();
        }

        private static bool Serializar (ISerializable obj)
        {
            return obj.SerializarXML();
        }
        static void Main(string[] args)
        {
            bool valor;            
            Cajon<Fruta> MiCajon = new Cajon<Fruta>(5,2);

            Manzana Manzana1 = new Manzana(1, ConsoleColor.Red, "Manzanita");
            Manzana Manzana2 = new Manzana(2, ConsoleColor.Green, "Manzanotas");

            Platano Banana1 = new Platano(1, ConsoleColor.Yellow, "Ecuador");
            Platano Banana2 = new Platano(2, ConsoleColor.Blue, "Argentina");

            Platano Banana3 = new Platano(3, ConsoleColor.Cyan, "Bolivia");

            try
            {
                MiCajon = MiCajon + Manzana1;
                MiCajon = MiCajon + Manzana2;
                MiCajon = MiCajon + Banana1;
                MiCajon = MiCajon + Banana2;
                MiCajon = MiCajon + Banana3;
            }
            catch (CajonLlenoException) { }

            Console.WriteLine(MiCajon.ToString());

            valor = Program.Serializar(MiCajon);
          //valor = Program.Deserealizar(MiCajon);
            Console.WriteLine(Program.ObtenerPreciosBD(MiCajon));
            
            Console.ReadLine();

        }
    }
}
