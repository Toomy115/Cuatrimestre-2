﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using System.IO;

namespace Entidades
{
    public delegate void CajonDelegado ();

    public class Cajon <T> : ISerializable
    {
        private int _capacidad;
        private List<T> _frutas;
        private float _precioUnitario;
        public event CajonDelegado EventoPrecio;

        public List<T> Frutas { get { return this._frutas; } }
        public float PrecioTotal
        {
            get
            {
                float cont = 0;
                foreach (object o in this.Frutas)
                {
                    cont += this._precioUnitario;
                }
                //if (cont > 25)
                    //this.EventoPrecio += new CajonDelegado(); ;
                return cont;
            }
            
        }
        public string RutaArchivo { get { return "guardado.xml"; } set { this.RutaArchivo = value; } }

        public Cajon()
        {
            this._frutas = new List<T>();
        }

        public Cajon(int capacidad)
            :this()
        {
            this._capacidad = capacidad;
        }

        public Cajon(int capacidad, float precio)
            : this(capacidad)
        {
            this._precioUnitario = precio;
        }

        public bool SerializarXML()
        {
            using (StreamWriter sw = new StreamWriter(this.RutaArchivo, false))
            {
                XmlSerializer xmls = new XmlSerializer(this.GetType(), new Type[] { typeof(Fruta), typeof(Manzana), typeof(Platano) });
                xmls.Serialize(sw, this);
            }
            return true;
        }

        public bool DeserealizarXML()
        {
            using (StreamReader sr = new StreamReader(this.RutaArchivo))
            {
                XmlSerializer xmls = new XmlSerializer(typeof(List<Fruta>));
                List<T> lista = new List<T>();
                lista = (List<T>)xmls.Deserialize(sr);
                foreach (T f in lista)
                {
                    Console.WriteLine(f.ToString());
                }
            }
            return true;
        }
        

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("CAJON\nCapacidad: " + this._capacidad + " Cantidad de frutas: " + this.Frutas.Count + " Precio Total: " + this.PrecioTotal);
            foreach (object o in this.Frutas)
            {
                sb.AppendLine(((Fruta)o).ToString());
            }
            return sb.ToString();
        }

        public static Cajon<T> operator +(Cajon<T> c, T f)
        {
            int tot = c.Frutas.Count + 1;
            if (tot < c._capacidad)
                c.Frutas.Add(f);
            else
                throw new CajonLlenoException("El cajon supero la cantidad maxima de frutas (" + c._capacidad + ")");
            return c;
        }
    }
}
