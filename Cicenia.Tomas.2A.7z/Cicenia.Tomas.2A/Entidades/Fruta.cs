﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public abstract class Fruta
    {
        private ConsoleColor _color;
        private float peso;

        public abstract bool TieneCarozo { get; }

        public Fruta() { }
        public Fruta(float peso, ConsoleColor color)
        {
            this._color = color;
            this.peso = peso;
        }

        protected virtual string FrutaToString()
        {
            //string tiene = this.TieneCarozo ? true = "Si":"No";
            return ("Peso: " + this.peso + " Color: " + this._color.ToString());
        }
    }
}
