﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Platano : Fruta
    {
        public string paisOrigen;

        public override bool TieneCarozo { get { return false; } }
        public string Tipo { get { return "Platano"; } }


        public Platano()
            : base()
        { }
        public Platano(float peso, ConsoleColor color, string pais)
            :base(peso,color)
        {
            this.paisOrigen = pais;
        }

        protected override string FrutaToString()
        {
            return (base.FrutaToString() + " Tiene Carozo: " + this.TieneCarozo + " Tipo: " + this.Tipo);
        }

        public override string ToString()
        {
            return this.FrutaToString();
        }
    }
}
